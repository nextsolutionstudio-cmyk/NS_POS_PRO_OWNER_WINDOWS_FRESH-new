package com.nspospro.ownercontrol;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.widget.Toast;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int LOGO_PICKER_REQUEST = 901;
    private static final int PAYMENT_EXPORT_REQUEST = 902;
    private String pendingPaymentExportJson;
    private WebView web;
    private ValueCallback<Uri[]> pendingFile;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        // Required to read the content:// URI returned by Android Photos/Files.
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);
        WebView.setWebContentsDebuggingEnabled(false);

        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void savePaymentsJson(String content) {
                if (content == null || (!content.trim().startsWith("{") || !content.contains("\"exported_at\"")) || content.length() > 2000000) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Invalid or too large payment export", Toast.LENGTH_LONG).show());
                    return;
                }
                runOnUiThread(() -> {
                    pendingPaymentExportJson = content;
                    Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    save.addCategory(Intent.CATEGORY_OPENABLE);
                    save.setType("application/json");
                    String date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
                    save.putExtra(Intent.EXTRA_TITLE, "NS_OWNER_Payments_" + date + ".json");
                    try { startActivityForResult(save, PAYMENT_EXPORT_REQUEST); } catch (Exception e) {
                        pendingPaymentExportJson = null;
                        Toast.makeText(MainActivity.this, "Cannot save payment export", Toast.LENGTH_LONG).show();
                    }
                });
            }
        }, "OwnerNative");

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"appassets.androidplatform.net".equalsIgnoreCase(request.getUrl().getHost());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view,
                ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (pendingFile != null) pendingFile.onReceiveValue(null);
                pendingFile = filePathCallback;
                try {
                    // Android 13+ can surface the system Photo Picker from this intent.
                    // On older devices the user can choose a Gallery or Files provider.
                    Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType("image/*");
                    pick.putExtra(Intent.EXTRA_MIME_TYPES,
                        new String[]{"image/png", "image/jpeg", "image/webp"});
                    pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(Intent.createChooser(pick, "Choose business logo"), LOGO_PICKER_REQUEST);
                } catch (Exception e) {
                    pendingFile.onReceiveValue(null);
                    pendingFile = null;
                    Toast.makeText(MainActivity.this,
                        "Cannot open Photos / Files picker", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });

        setContentView(web);
        try (InputStream input = getAssets().open("index.html");
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int size;
            while ((size = input.read(buffer)) != -1) output.write(buffer, 0, size);
            String html = output.toString(StandardCharsets.UTF_8.name());
            web.loadDataWithBaseURL("https://appassets.androidplatform.net/",
                html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            Toast.makeText(this, "Owner portal failed to load", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PAYMENT_EXPORT_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingPaymentExportJson != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IllegalStateException("No output stream");
                    out.write(pendingPaymentExportJson.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Payment export saved", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Could not write payment export", Toast.LENGTH_LONG).show();
                }
            }
            pendingPaymentExportJson = null;
            return;
        }
        if (requestCode != LOGO_PICKER_REQUEST || pendingFile == null) return;
        Uri[] result = null;
        if (resultCode == Activity.RESULT_OK && data != null) {
            if (data.getData() != null) result = new Uri[]{data.getData()};
            else if (data.getClipData() != null && data.getClipData().getItemCount() > 0)
                result = new Uri[]{data.getClipData().getItemAt(0).getUri()};
        }
        pendingFile.onReceiveValue(result);
        pendingFile = null;
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (pendingFile != null) {
            pendingFile.onReceiveValue(null);
            pendingFile = null;
        }
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
